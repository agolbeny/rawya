# setuptourist

dependencies:
- node v13
- npm
- mysql
